window.View = function (selector){
    return  document.querySelector(selector)
}